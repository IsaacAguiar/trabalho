import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import './Menu.css';
import BuscarMedicos from '../Icones/buscarMedicos';
import UsuariosCadastrados from '../Icones/usuariosCadastrados';
import Planos from '../Icones/planos';
import Pagamentos from '../Icones/pagamentos';
import Especialidades from '../Icones/especialidades';
import Notificacoes from '../Icones/notificacoes';
import FaqIcone from '../Icones/faq';
import Dashboard from '../Icones/dashboard';

const Menu: React.FC = () => {
  const [showPagamentosSubMenu, setShowPagamentosSubMenu] = useState(false);
  const navigate = useNavigate(); 

  const handleNavigation = (route: string) => {
    navigate(route); 
  };

  const togglePagamentosSubMenu = () => {
    setShowPagamentosSubMenu(!showPagamentosSubMenu);
  };

  return (
    <div className="menu">
      <nav>
        <ul>
          <li>
            <div className='buscarMedicos'>
              <BuscarMedicos />
            </div>
          </li>

          <li onClick={() => handleNavigation('/dashboard')}>
            <div className='itens'>
              <Dashboard />
              <span>Dashboard</span>
            </div>
          </li>

          <li onClick={() => handleNavigation('/usuarios-cadastrados')}>
            <div className='itens'>
              <UsuariosCadastrados />
              <span>Usuários Cadastrados</span>
            </div>
          </li>

          <li onClick={() => handleNavigation('/planos')}>
            <div className='itens'>
              <Planos />
              <span>Planos</span>
            </div>
          </li>

          <li>
            <div className='itens pagamento' onClick={togglePagamentosSubMenu}>
              <Pagamentos />
              <span>Pagamentos</span>
            </div>
            {showPagamentosSubMenu && (
              <ul className="submenu">
                <li className='subItens' onClick={() => handleNavigation('/pagamentos/contratante')}>Contratante</li>
                <li className='subItens' onClick={() => handleNavigation('/pagamentos/medico')}>Médico</li>
              </ul>
            )}
          </li>

          <li onClick={() => handleNavigation('/especialidades')}>
            <div className='itens'>
              <Especialidades />
              <span>Especialidades</span>
            </div>
          </li>

          <li onClick={() => handleNavigation('/notificacoes')}>
            <div className='itens'>
              <Notificacoes />
              <span>Notificações</span>
            </div>
          </li>

          <li onClick={() => handleNavigation('/faq')}>
            <div className='itens'>
              <FaqIcone />
              <span>FAQ</span>
            </div>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Menu;