import React from "react";
import './avatarTopo.css'

const AvatarTopo: React.FC = () => {
  return (
    <div className="teste">
      <div>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="56"
          height="56"
          fill="none"
          viewBox="0 0 56 56"
        >
          <circle cx="28" cy="28" r="28" fill="#046639"></circle>
          <path
            stroke="#fff"
            strokeLinecap="round"
            strokeWidth="2"
            d="M38.303 39.263c-.608-1.701-1.947-3.204-3.81-4.276-1.863-1.073-4.145-1.654-6.493-1.654-2.348 0-4.63.581-6.494 1.654-1.862 1.072-3.202 2.575-3.81 4.276"
          ></path>
          <ellipse
            cx="28"
            cy="22.667"
            stroke="#fff"
            strokeLinecap="round"
            strokeWidth="2"
            rx="5.333"
            ry="5.333"
          ></ellipse>
        </svg>
      </div>
      <div className="nomeEmail">
        <div className="nome">Isaac Aguiar</div>
        <div className="email">isaacgoncales@gmail.com</div>
      </div>

      <div>
          <svg
          xmlns="http://www.w3.org/2000/svg"
          width="16"
          height="16"
          fill="none"
          viewBox="0 0 16 16"
        >
          <path
            fill="#757575"
            stroke="#757575"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="0.5"
            d="M13.864 4.803l-.177.177.177-.177a.75.75 0 00-1.06 0L8 9.606 3.197 4.803a.75.75 0 00-1.06 1.06l5.333 5.334a.75.75 0 001.06 0l5.334-5.333a.75.75 0 000-1.061z"
          ></path>
          </svg>
      </div>
    </div>
  );
};

export default AvatarTopo;
