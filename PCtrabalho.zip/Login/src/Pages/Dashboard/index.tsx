import React from 'react';
import './dashboard.css'
import Menu from '../../Components/Menu';
import MenuSuperior from "../../Components/MenuSuperior"
import RelogioDashboard from '../../Components/RelogioDashboard'
import bemVindo from '../../assets/images/bemVindo.png'

const App: React.FC = () => {
  return (
    <div className="App">
      <Menu />

      <div className="content">
        <div>
          <MenuSuperior />
        </div>
        
        <div className='containerGrandeDash'>
            <div className='containersDash'>
              <img src={bemVindo} alt="Bem-vindo" className='bemVindo'/>
              <div className='posicionamento'>
                <RelogioDashboard/>
              </div>
            </div>

          <div className='containersPequenosDash'>
            <div className='pequenoDash'></div>
            <div className='pequenoDash'></div>
          </div>
        </div>

        <div className='containertableDash'>
         
        </div>
       

      </div>
    </div>
  );
};

export default App;
